import java.io.*;
import java.util.Scanner;

public class MoveMagicSquare
{
    public static void main(String[] args)
    {
        try
        {
            int[] starting;
            starting= new int[9];

            File files= new File("/home/arehone/IdeaProjects/AI/src/B.txt");
            reading(files, starting);

            State start= new State(State.find9(starting), starting);
            State goal = State.greedySearch(start);
            if (goal != null)
            {
                System.out.println("The goal is found");
                goal.printState();
            }
            else
            {
                System.out.println("Sorry we can't find a goal state below 700 moves");
            }
            File outputFileA = new File("A.txt");
            file_write(outputFileA,start);

        }
        catch (Exception e)
        {
            System.out.println("Error reading in the file Or in the content of the file...");
            System.exit(0);
        }
    }


    public static void reading(File path, int[] initialState)
    {
        try
        {
            Scanner scanner = new Scanner(path);
            for (int i = 0; i < initialState.length; i++)
                initialState[i] = scanner.nextInt();
            scanner.close();
        } catch (Exception e)
        {
            System.out.println("Error while reading the file: " + e.getMessage());
            System.exit(0);
        }
    }
    public static void file_write(File file_path, State startNode)
    {
        try
        {
            File outputFile = new File(String.valueOf(file_path));
            PrintStream output = new PrintStream(outputFile);
            System.setOut(output);

            State result = State.greedySearch(startNode);
            if (result == null)
                System.out.println("No solution found below 700 moves");else
                System.out.println("The file found the goal state for you");
                result.printState();
            output.close();
        }
        catch (Exception c)
        {
            System.out.println("Error while writing the file");
        }
    }
}//End of MoveMagicSquare Class