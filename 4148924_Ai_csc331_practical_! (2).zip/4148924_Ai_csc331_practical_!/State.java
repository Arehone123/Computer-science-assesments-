import java.util.*;
class State implements Comparable<State> {
    private final int hValue;
    private int pos9;
    private int[] board = new int[9];
    private static int nm;
    private final static int K = 15,N = 3,MAX_MOVES = 700;
    public State(int position9, int[] aboard)
    {
        this.pos9 = position9;
        for (int i = 0; i < aboard.length; i++)
            board[i] = aboard[i];
        hValue = calculateHValue();
    }
    @Override
    public int compareTo(State o)
    {
        return (this.hValue - o.hValue);
    }

    public int getHValue()
    {
        return hValue;
    }
    public int getPos9() {
        return pos9;
    }
    public void setPos9(int newPos) {
        pos9 = newPos;
    }
    public int[] getBoard() {
        return board;
    }
    public void setBoard(int[] board) {
        this.board = board;
    }

    public int calculateHValue() {
        int sum = 0;

        for (int i = 0; i < N; i++) {
            int rowSum = 0;
            int colSum = 0;

            for (int j = 0; j < N; j++) {
                rowSum += board[i * N + j];
                colSum += board[j * N + i];
            }

            int rowDiff = Math.abs(K - rowSum);
            int colDiff = Math.abs(K - colSum);

            sum += rowDiff + colDiff;
        }

        int diagonalSum1 = board[2] + board[4] + board[6];
        int diagonalSum2 = board[0] + board[4] + board[8];

        int diagonalDiff1 = Math.abs(K - diagonalSum1);
        int diagonalDiff2 = Math.abs(K - diagonalSum2);

        sum += diagonalDiff1 + diagonalDiff2;

        return sum;
    }

    public static State greedySearch(State startState) {
        int maxMoves = MAX_MOVES;
        int numMoves = 0;

        PriorityQueue<State> queue = new PriorityQueue<>();
        Set<String> visitedNodes = new HashSet<>();

        queue.add(startState);

        while (!queue.isEmpty() && numMoves <= maxMoves) {
            State currentState = queue.remove();

            if (currentState.getHValue() == 0) {
                return currentState;
            }

            currentState.printState();
            numMoves++;

            String stateString = "[" + String.join(",", Arrays.stream(currentState.getBoard())
                    .mapToObj(String::valueOf).toArray(String[]::new)) + "]";

            if (!visitedNodes.contains(stateString)) {
                visitedNodes.add(stateString);
                queue.addAll(currentState.generateChildrenStates());
            }
        }

        return null;
    }


    public ArrayList<State> generateChildrenStates() {
        ArrayList<State> children = new ArrayList<>();
        int[][] moves = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        for (int[] move : moves) {
            int newRow = pos9 / N + move[0];
            int newCol = pos9 % N + move[1];

            if (isValidPosition(newRow, newCol)) {
                int newPos = newRow * N + newCol;
                int[] newBoard = Arrays.copyOf(board, board.length);
                swap(newBoard, pos9, newPos);
                children.add(new State(newPos, newBoard));
            }
        }

        return children;
    }

    private boolean isValidPosition(int row, int col) {
        return row >= 0 && row < N && col >= 0 && col < N;
    }

    private void swap(int[] arr, int i, int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public void printState() {
        System.out.println("Current board state hValue:  " + hValue);
        if (hValue!= 0) {
            System.out.println("Number of nm: " + nm);
        } else {
            System.out.println("Total states visited is : " + (nm));
        }
        for (int y = 0; y < board.length; y++) {
            System.out.print(board[y] + " ");
            if ((y + 1) % 3 == 0) {
                System.out.println();
            }
        }System.out.println();
    }

    public static int find9(int[] initial_State) {
        for (int x = 0; x < initial_State.length; x++) {
            if (initial_State[x] == 9) {
                return x;
            }
        }
        return 0;
    }
}